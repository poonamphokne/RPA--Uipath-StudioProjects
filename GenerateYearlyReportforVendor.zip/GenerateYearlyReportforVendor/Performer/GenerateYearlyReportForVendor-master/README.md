# Generate Yearly Report for Vendor: 年次レポートの生成（パフォーマー）
UiPath Level 3 - Advanced Training（日本語）課題②

UiPath AcademyのUiPath Level 3 - Advanced Training（日本語）で提出を求められる課題のワークフローです。ReFrameworkを使った業務プロセスとして完結したワークフローなので、参考になる点も多いかと思います。
